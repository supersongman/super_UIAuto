# 小宋测试平台
##介绍
* 环境：后端python3.9.10（flask）+前端node+vue3.2.26+数据库mysql5.7.37
* 依赖：pip install -r requirements.txt
* 思路：vue提供前端页面层，flask提供后端接口层，mysql进行数据存储层，底层服务打包成2个windows可执行文件并进环境变量配置，分别通过super-webrun和super-apirun进行运行
##使用
* 前端运行：cd frontend && npm run dev
* 后端运行：cd backend && python3.9 run app.py
* 服务打包：cd backend && python3.9 setup.py install
##功能
* 支持多用户登录
* 支持用户注册
* 支持用户修改密码
* 支持用户修改个人信息
* 接口定义
* 接口debug
* 单接口测试
* 批量接口测试
* 测试报告在线查看
* 测试报告邮件发送
* 测试报告定时发送
* ui自动化测试定义
* ui页面定义
* ui页面元素定义
* ui页面元素定位方式
* ui页面元素操作
* ui页面元素断言
* ui测试用例复用
* 单ui页面测试
* 全ui页面测试
* 分布式ui测试
* 定时进行ui测试
* 在线查看ui测试报告
* 邮件发送ui测试报告
* 测试报告定时发送
##部署
* 1、前端部署：将前端打包好的dist文件部署到nginx中，配置好静态文件目录，访问地址为：http://ip:port/
* 2、后端部署：后端用gunicorn 部署，配置好gunicorn.service文件或者在项目根目录下运行python3 -m gunicorn -w 4 app:application，启动即可
##后续扩展
* 同步接口进行异步改造
* 图表统计及导出
* 账号权限控制
* ui美化
* app自动化

