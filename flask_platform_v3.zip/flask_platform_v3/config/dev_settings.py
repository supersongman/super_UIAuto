# 开发环境--需要的配置
SQLALCHEMY_DATABASE_URI = 'mysql+pymysql://youraccount:yourpassword@xxx.xxx.xxx.xxx:3306/platfrom?charset=utf8'
SQLALCHEMY_TRACK_MODIFICATIONS = True
# 打印sql语句
SQLALCHEMY_ECHO = True
SECRET_KEY = "1234567812345678"
# 接口自动化路径
CASES_ROOT_DIR = r"/Users/mac/Documents/自动化平台搭建/auto-data/api_case"
REPORT_ROOT_DIR = r"/Users/mac/Documents/自动化平台搭建/auto-data/api_report"

# ui自动化路径
CASE_ROOT_WEB_DIR = r"/Users/mac/Documents/自动化平台搭建/auto-data/ui_yaml"  # 测试用例生成的文件夹
KEY_WORDS_DIR = r"/Users/mac/Documents/自动化平台搭建/auto-data/ui_keyswords"  # 关键字生成的文件夹
# ui测试报告存放的路径
UI_CASES_ROOT_DIR = r"/Users/mac/Documents/自动化平台搭建/auto-data/ui_case"  # 用例数据文件夹
UI_REPORT_ROOT_DIR = r"/Users/mac/Documents/自动化平台搭建/auto-data/ui_report"  # 用例报告文件夹
UPLOAD_FILES_DEST = r'/Users/mac/Documents/自动化平台搭建/auto-data/uploads'

# 通义千问相关
# AccessKey ID LTAI5tEoiGCf4i1k3zTwCLFo
# AccessKey Secret dUSUnZS11tiTzFUmmh3itQHCI6DPi1