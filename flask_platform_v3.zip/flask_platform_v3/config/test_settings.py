# 测试环境
SQLALCHEMY_DATABASE_URI = 'mysql+pymysql://youraccount:yourpassword@192.xxx.xxx.x:3306/platfrom?charset=utf8'
SQLALCHEMY_TRACK_MODIFICATIONS = True