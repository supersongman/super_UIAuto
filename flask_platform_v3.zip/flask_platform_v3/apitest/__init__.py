import os,subprocess
# rs = os.system(r"E:&cd E:\platfrom\code\apirunner&E:\platfrom\code\venv\Scripts\activate&python cli.py")
# print(rs)

import subprocess

# 定义命令列表
# import subprocess
#
# # 定义远程命令
# remote_command = "E:&cd E:\\platfrom\\code\\apirunner && E:\\platfrom\\code\\venv\\Scripts\\activate && python cli.py --suite_name=docase_1"
#
# # 执行远程命令
# rs = subprocess.check_output(remote_command, shell=True,universal_newlines=True,encoding='utf-8')
# print(rs)

