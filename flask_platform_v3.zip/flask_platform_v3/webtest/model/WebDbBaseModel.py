from app import database

class WebDbBase(database.Model):
    """
    Web数据库基础类，继承自database.Model，代表数据库中的一个实体。
    用于定义与Web数据库相关的属性和行为。
    """

    __tablename__ = "t_web_database"  # 表名

    id = database.Column(database.Integer, primary_key=True, autoincrement=True)
    # 主键，自动增长的整数，用于唯一标识每个数据库实体

    project_id = database.Column(database.Integer, comment="项目id")
    # 关联的项目ID，整数类型

    name = database.Column(database.String(255), comment="连接名")
    # 数据库连接的名称，字符串类型，最长255个字符

    ref_name = database.Column(database.String(255), comment="引用变量")
    # 引用变量名，字符串类型，最长255个字符

    db_type = database.Column(database.String(255), comment='数据库类型')
    # 数据库的类型，如MySQL、PostgreSQL等，字符串类型，最长255个字符

    db_info = database.Column(database.String(255), comment='数据库连接信息')
    # 数据库的连接信息，通常包含用户名、密码、主机等，字符串类型，最长255个字符

    is_enabled = database.Column(database.String(255), comment='是否启用')
    # 表示数据库是否启用的标志，字符串类型，最长255个字符

    create_time = database.Column(database.DateTime)
    # 记录数据库实体的创建时间，DateTime类型
