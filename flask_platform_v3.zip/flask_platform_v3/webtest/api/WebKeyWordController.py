from flask import Blueprint, request
from core.resp_model import respModel
from app import database, application
from webtest.model.WebKeyWordModel import WebKeyWord
from datetime import datetime
import os

# 模块信息
module_name = "WebKeyWord"  # 模块名称
module_model = WebKeyWord
module_route = Blueprint(f"route_{module_name}", __name__)


@module_route.route(f"/{module_name}/queryByPage", methods=["POST"])
def queryByPage():
    """
    查询数据(支持模糊搜索)

    参数:
    - 通过请求体（JSON）接收页码（page）和每页大小（pageSize）

    返回值:
    - 返回一个包含查询结果列表和总数的响应对象
    """

    try:
        # 分页查询参数解析
        page = int(request.json["page"])
        page_size = int(request.json["pageSize"])
        with application.app_context():
            filter_list = []
            filter_list = []
            # 添加项目筛选条件
            operation_type_id = request.json.get("operation_type_id", 0)
            if type(operation_type_id) is not str and operation_type_id > 0:
                filter_list.append(module_model.operation_type_id == operation_type_id)
            # module_id = request.json.get("module_id", 0)
            # if type(module_id) is not str and project_id > 0:
            #     filter_list.append(module_model.project_id == project_id)
            # 添加模块名称模糊搜索条件
            name = request.json.get("name", "")
            if len(name) > 0:
                filter_list.append(module_model.name.like(f"%{name}%"))
            page_id = request.json.get("page_id", 0)
            if type(page_id) is not str and page_id > 0:
                filter_list.append(module_model.page_id == page_id)
            datas = module_model.query.filter(*filter_list).limit(page_size).offset((page - 1) * page_size).all()
            total = module_model.query.filter(*filter_list).count()
            return respModel().ok_resp_list(lst=datas, total=total)
    except Exception as e:
        print(e)
        return respModel.error_resp(f"服务器错误,请联系管理员:{e}")


@module_route.route(f"/{module_name}/queryById", methods=["GET"])
def queryById():
    """
    查询数据(单条记录)

    参数:
    - 通过查询参数接收记录ID（id）

    返回值:
    - 返回查询到的单条数据或无数据的提示响应对象
    """

    try:
        data_id = int(request.args.get("id"))
        with application.app_context():
            # 根据ID查询数据
            data = module_model.query.filter_by(id=data_id).first()
        if data:
            return respModel().ok_resp(obj=data)
        else:
            return respModel.ok_resp(msg="查询成功,但是没有数据")
    except Exception as e:
        print(e)
        return respModel.error_resp(f"服务器错误,请联系管理员:{e}")


# @module_route.route(f"/{module_name}/insert", methods=["POST"])
# def insert():
#     """
#     新增数据
#
#     参数:
#     - 通过请求体（JSON）接收数据字段
#
#     返回值:
#     - 返回添加结果的响应对象，包含新增记录的ID
#     """
#
#     try:
#         with application.app_context():
#             # 设置ID为None以触发自增长
#             data = module_model(**request.json, create_time=datetime.strftime(datetime.today(), '%Y-%m-%d %H:%M:%S'))
#             database.session.add(data)
#             # 提交后获取新增数据的ID
#             database.session.flush()
#             data_id = data.id
#             database.session.commit()
#         return respModel.ok_resp(msg="添加成功", dic_t={"id": data_id})
#     except Exception as e:
#         return respModel.error_resp(msg=f"添加失败:{e}")


# @module_route.route(f"/{module_name}/update", methods=["PUT"])
# def update():
#     """
#     修改数据
#
#     参数:
#     - 通过请求体（JSON）接收需要修改的数据字段，包括ID
#
#     返回值:
#     - 返回修改结果的响应对象
#     """
#
#     try:
#         with application.app_context():
#             # 根据ID更新数据
#             module_model.query.filter_by(id=request.json["id"]).update(request.json)
#             database.session.commit()
#         return respModel.ok_resp(msg="修改成功")
#     except Exception as e:
#         print(e)
#         return respModel.error_resp(msg=f"修改失败，请联系管理员:{e}")


@module_route.route(f"/{module_name}/delete", methods=["DELETE"])
def delete():
    """
    删除数据

    参数:
    - 通过查询参数接收要删除的记录ID

    返回值:
    - 返回删除结果的响应对象
    """

    try:
        with application.app_context():
            # 根据ID删除记录
            module_model.query.filter_by(id=request.args.get("id")).delete()
            database.session.commit()
        return respModel.ok_resp(msg="删除成功")
    except Exception as e:
        print(e)
        return respModel.error_resp(msg=f"服务器错误,删除失败：{e}")


@module_route.route(f"/{module_name}/queryAll", methods=["GET"])
def queryAll():
    try:
        with application.app_context():

            datas = module_model.query.all()

        return respModel.ok_resp_list(lst=datas, msg="查询成功")
    except Exception as e:
        print(e)
        return respModel.error_resp(msg=f"服务器错误：{e}")


# 修改新增接口，当keyword_fun_name 在数据库则不能添加
@module_route.route(f"/{module_name}/insert", methods=["POST"])
def insert():
    try:
        with application.app_context():
            request.json["id"] = None
            keyword_fun_name = request.json["keyword_fun_name"]  # 获取关键字名称
            data = module_model.query.filter_by(keyword_fun_name=keyword_fun_name).first()
            if data:
                return respModel.error_resp(msg="关键字名称已存在,请重新输入")
            else:
                data = module_model(**request.json,
                                    create_time=datetime.strftime(datetime.today(), '%Y-%m-%d %H:%M:%S'))
                database.session.add(data)
                database.session.flush()
                data_id = data.id
                database.session.commit()
                return respModel.ok_resp(msg="添加成功", dic_t={"id": data_id})
    except Exception as e:
        return respModel.error_resp(msg=f"添加失败:{e}")


# 修改修改接口，当keyword_fun_name 在数据库则不能修改
@module_route.route(f"/{module_name}/update", methods=["PUT"])
def update():
    try:
        with application.app_context():
            keyword_fun_name = request.json["keyword_fun_name"]
            keyword_id = request.json["id"]  # 获取id,更新的是当前数据/查询的也是这个数据，则过滤
            data = module_model.query.filter_by(keyword_fun_name=keyword_fun_name).first()
            if data and (data.id != keyword_id):
                return respModel.error_resp(msg="关键字名称已存在,请重新输入")
            else:
                module_model.query.filter_by(id=request.json["id"]).update(request.json)
            database.session.commit()
        return respModel.ok_resp(msg="修改成功")

    except Exception as e:
        return respModel.error_resp(msg=f"修改失败:{e}")


# 生成关键字文件
@module_route.route(f"/{module_name}/keywordFile", methods=["POST"])
def keywordFile():
    try:
        with application.app_context():
            file_name = request.json["keyword_fun_name"]  # 方法名
            keyword_value = request.json["keyword_value"]  # 方法体
            # 关键字目录
            key_words_dir = application.config["KEY_WORDS_DIR"]
            os.makedirs(key_words_dir, exist_ok=True)  # 没有则新建
            with open(f"{key_words_dir}/{file_name}.py", "w", encoding="utf-8") as f:
                f.write(keyword_value)
            return respModel.ok_resp(msg="生成关键字文件成功", dic_t={"id": file_name})

    except Exception as e:
        print(e)
        return respModel.error_resp(msg=f"生成关键字文件失败:{e}")


from webtest.model.WebOperationTypeModel import OperationType


# 级联数据查询
@module_route.route(f"/{module_name}/queryAllKeyWordList", methods=["GET"])
def queryAllKeyWordList():
    try:
        with application.app_context():
            all_datas = []

            allOperationType = OperationType.query.all()
            for data in allOperationType:
                #  初始数据
                apidata = {"id": "", "value": "", "label": "", "children": []}
                # 设置父类
                apidata["id"] = data.id
                apidata["value"] = data.ex_fun_name
                apidata["label"] = data.operation_type_name

                # 搜索当前操作方法的对应的关键字方法并且设置为子类
                apiKeydata = module_model.query.filter(module_model.operation_type_id == data.id).all()
                for data in apiKeydata:
                    i = {}
                    i["id"] = data.id
                    i["value"] = data.keyword_fun_name
                    i["label"] = data.name
                    i["keyword_desc"] = data.keyword_desc
                    apidata["children"].append(i)

                #  把对应的数据加入到到所有数据中。
                all_datas.append(apidata)
            print("打印看看拼接后的数据：", all_datas)
            return respModel().ok_resp_listdata(lst=all_datas, msg="查询成功")
    except Exception as e:
        print(e)
    # 注意这里的返回数据，不能用之前的响应，因为这个是我们拼接的数据，没有特殊的数据，直接返回就好了。
        return respModel.error_resp(msg=f"{e}")
