from flask_wtf import FlaskForm
from wtforms import FileField, SubmitField
from wtforms.validators import DataRequired

class ExcelUploadForm(FlaskForm):
    excel_file = FileField('上传 Excel 文件', validators=[DataRequired()])
    submit = SubmitField('上传')
