"""
excel相关操作
"""
import pandas as pd
from ruamel.yaml import YAML


class ReadExcel():
    def __init__(self):
        pass

    def represent_str(self, dumper, data):
        if '\n' in data:
            return dumper.represent_scalar('tag:yaml.org,2002:str', data, style='|')
        return dumper.represent_scalar('tag:yaml.org,2002:str', data)

    def get_all_data(self, path, sheetname):
        if sheetname == "Airbus TO":
            # 读取 Excel 文件以确定总列数
            temp_df = pd.read_excel(path, sheet_name=sheetname, skiprows=1, header=0)
            total_columns = len(temp_df.columns)
            # 读取第3到10列，第12到20列，和最后三列

            # 读取 Excel 文件
            df = pd.read_excel(path, sheet_name=sheetname,
                               usecols=list(range(3, 18)) + list(range(total_columns - 3, total_columns)), skiprows=1,
                               header=0)

            # 获取表头
            data_title = df.columns.tolist()
            # 读取 Excel 文件以确定总列数
            temp_df = pd.read_excel(path, sheet_name=sheetname, skiprows=1, header=0)
            total_columns = len(temp_df.columns)

            # 处理第二列数据
            if len(data_title) > 1:  # 确保至少有两列
                second_column = data_title[1]
                df[second_column] = df[second_column].apply(lambda x: x.split('-')[-1] if '-' in str(x) else x)

            # 存储数据
            data = []
            for index, row in df.iterrows():
                filtered_row = [row[col] for col in data_title]
                data.append(dict(zip(data_title, filtered_row)))
            print(data)
        if sheetname == "Boeing TO":

            # 读取 Excel 文件以确定总列数
            temp_df = pd.read_excel(path, sheet_name=sheetname, skiprows=1, header=0)
            total_columns = len(temp_df.columns)
            # 读取第3到10列，第12到20列，和最后三列
            columns_to_read = list(range(3, 11)) + list(range(12, 19)) + list(range(total_columns - 3, total_columns))
            df = pd.read_excel(path, sheet_name=sheetname, usecols=columns_to_read, skiprows=1, header=0)

            # 获取表头
            data_title = df.columns.tolist()
            # 处理第一列数据，去掉首字母
            if not df.empty:
                first_column = df.columns[0]
                df[first_column] = df[first_column].apply(lambda x: str(x)[1:] if len(str(x)) > 0 else x)
                # 处理第二列数据，去掉“-”之前的部分
            if len(data_title) > 1:  # 确保至少有两列
                second_column = df.columns[1]
                df[second_column] = df[second_column].apply(lambda x: x.split('-')[-1] if '-' in str(x) else x)
            # 存储数据
            data = []
            for index, row in df.iterrows():
                filtered_row = [row[col] for col in data_title]
                data.append(dict(zip(data_title, filtered_row)))
            print(data)
        if sheetname == "Airbus LD":
            # 读取 Excel 文件以确定总列数
            temp_df = pd.read_excel(path, sheet_name=sheetname, skiprows=1, header=0)
            total_columns = len(temp_df.columns)

            # 读取 Excel 文件
            df = pd.read_excel(path, sheet_name=sheetname, usecols=list(range(3, 20)) + list(range(21, 22)) + list(
                range(total_columns - 3, total_columns)), skiprows=1, header=0)

            # 获取表头
            data_title = df.columns.tolist()
            # 处理第三列数据，去掉首字母
            if len(data_title) > 2:  # 确保至少有三列
                third_column = data_title[2]
                df[third_column] = df[third_column].apply(lambda x: x.split('-')[-1] if '-' in str(x) else x)

            # 存储数据
            data = []
            for index, row in df.iterrows():
                filtered_row = [row[col] for col in data_title]
                data.append(dict(zip(data_title, filtered_row)))
            print(data)
        if sheetname == "BOEING LD":
            # 读取 Excel 文件以确定总列数
            temp_df = pd.read_excel(path, sheet_name=sheetname, skiprows=1, header=0)
            total_columns = len(temp_df.columns)

            # 读取 Excel 文件
            df = pd.read_excel(path, sheet_name=sheetname, usecols=list(range(3, 17)) + list(range(18, 20)) + list(
                range(total_columns - 3, total_columns)), skiprows=1, header=0)

            # 获取表头
            data_title = df.columns.tolist()
            # 处理第二列数据
            if len(data_title) > 1:  # 确保至少有两列
                second_column = data_title[1]
                df[second_column] = df[second_column].apply(lambda x: str(x)[1:] if len(str(x)) > 0 else x)

            # 处理第三列数据
            if len(data_title) > 2:  # 确保至少有三列
                third_column = data_title[2]
                df[third_column] = df[third_column].apply(lambda x: x.split('-')[-1] if '-' in str(x) else x)

            # 存储数据
            data = []
            for index, row in df.iterrows():
                filtered_row = [row[col] for col in data_title]
                data.append(dict(zip(data_title, filtered_row)))
            print(data)
        return data

    def write_exceldata_yaml(self, yaml_path, excel_path, sheetname):
        yaml = YAML()
        yaml.default_flow_style = False
        yaml.sort_keys = False
        # 配置 YAML 对象以避免布尔值自动解析
        yaml.boolean_representation = ['false', 'true']
        yaml.representer.add_representer(str, self.represent_str)

        datas = self.get_all_data(excel_path, sheetname)
        print(f"Datas: {datas}")  # 添加调试信息

        # 读取现有的 YAML 文件内容
        try:
            with open(yaml_path, 'r', encoding='utf-8') as file:
                existing_data = yaml.load(file)
        except FileNotFoundError:
            existing_data = {}
            # 确保 existing_data 是一个字典
        except Exception as exc:
            print(f"Error reading YAML file: {exc}")
            existing_data = {}

        # 初始化 ddts 列表
        if "ddts" not in existing_data:
            existing_data["ddts"] = []

        # 处理 datas 中的每个元素
        for ddt_data in datas:
            print(f"DDT Data: {ddt_data}")  # 添加调试信息
            if isinstance(ddt_data, dict):
                # 直接将 ddt_data 添加到 ddts 列表中
                existing_data["ddts"].append(ddt_data)
            else:
                print(f"Unexpected data type: {type(ddt_data)}")

        # 写入更新后的数据到 YAML 文件
        with open(yaml_path, 'w', encoding='utf-8') as file:
            yaml.dump(existing_data, file)


if __name__ == "__main__":
    file_path = "/Users/mac/Documents/自动化平台搭建/auto-data/测试文档.xlsx"  # 此处填写Excel路径
    sheet_name = "Airbus TO"  # 此处填写sheet名
    yaml_path = "/Users/mac/Documents/自动化平台搭建/auto-data/ui_yaml/b/1_25a77229-e5ec-4991-9acc-128a8d81e2b1.yaml"  # 此处填写yaml文件名
    reader = ReadExcel()
    reader.write_exceldata_yaml(yaml_path, file_path, sheet_name)
    # reader.get_all_data(file_path, sheet_name)
'''
1_25a77229-e5ec-4991-9acc-128a8d81e2b1.yaml  空客起飞  Airbus TO
2_eceb6a4b-07f0-4d76-8c47-e87ac602c237.yaml  空客着陆  Airbus LD
3_5f10f1e1-55cd-436a-8817-f9649034d1e4.yaml  波音起飞  Boeing TO
4_f152c00c-b2a5-4097-9515-091b18048704.yaml  波音着陆  BOEING LD
'''
