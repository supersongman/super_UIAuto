from core.excelUtil import ExcelUtil


def excel_to_tuvdata(excelpath, sheetname, start_row):
    """
    将excel数据转换为tuv数据
    :param excelpath:路径
    :param sheetname:表名
    :param start_row:开始遍历的行
    :return:
    """
    alldatas = []
    util = ExcelUtil(excelpath)
    data = util.read_by_rows(sheetname, start_row)
    for row in data:
        alldatas.append(row)
    return alldatas
