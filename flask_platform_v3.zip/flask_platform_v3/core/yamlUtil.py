import yaml, json


def generate_yaml(json_data, url_path):
    if url_path is None:
        raise ValueError("The 'filname' parameter is required.")

    url_path = url_path

    # 检查json_data是否是字典或JSON字符串
    if isinstance(json_data, dict):
        # 已经是字典，直接转换
        with open(url_path, 'w', encoding='utf-8') as file:
            yaml.dump(json_data, file, default_flow_style=False, sort_keys=False, allow_unicode=True)
    elif isinstance(json_data, str):
        try:
            # 尝试将JSON字符串加载为字典
            json_data = json.loads(json_data)
            with open(url_path, 'w', encoding='utf-8') as file:
                yaml.dump(json_data, file, default_flow_style=False, sort_keys=False, allow_unicode=True)
        except json.JSONDecodeError:
            raise ValueError("The provided string is not a valid JSON.")
    else:
        raise ValueError("The 'json_data' parameter must be a dictionary or a JSON string.")
