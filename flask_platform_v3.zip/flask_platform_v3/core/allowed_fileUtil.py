def allowed_file(filename):
    ALLOWED_EXTENSIONS = {'xls', 'xlsx', 'xlsm'}  # 允许的Excel文件扩展名
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS
