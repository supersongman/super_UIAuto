import openpyxl


class ExcelUtil():
    def __init__(self, excelPath, index=None):
        if index is None:
            index = 0
        self.data = openpyxl.load_workbook(excelPath)
        self.table = self.data.worksheets[index]

    def get_sheet_by_name(self, sheetName):
        """
        获取指定名称的工作表
        :param sheetName: 工作表名称
        :return: 工作表对象
        """
        return self.data[sheetName]

    def read_by_rows(self, sheetName, min_row=2):

        """
        按行读取Excel数据，从第二行开始，第二行为键，后续行为值
        :param sheetName: 工作表名称
        :param min_row: 开始读取的行数，默认为2（即第二行）
        :return: 字典列表，每个字典表示一行数据，键为第二行的值
        """
        sheet = self.get_sheet_by_name(sheetName)

        # 获取第二行作为键
        keys = [cell for cell in next(sheet.iter_rows(min_row=min_row, max_row=min_row, values_only=True))]

        # 从第三行开始读取数据
        data_list = []
        for row in sheet.iter_rows(min_row=min_row + 1, values_only=True):
            row_data = dict(zip(keys, row))
            data_list.append(row_data)

        return data_list


# 使用示例
if __name__ == "__main__":
    util = ExcelUtil("../jennify.xlsx")
    data = util.read_by_rows("Sheet1", 2)
    for row in data:
        print(row)
