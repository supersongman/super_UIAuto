from flask import Blueprint, request
from core.resp_model import respModel
from app import database, application
from phone.model.PhoneModel import Phone
from datetime import datetime

# 模块信息
module_name = "phone"  # 模块名称
module_model = Phone
module_route = Blueprint(f"route_{module_name}", __name__)


@module_route.route(f"/{module_name}/queryByPage", methods=["POST"])
def queryByPage():
    """
    查询数据(支持模糊搜索)

    参数:
    - 通过请求体（JSON）接收页码（page）和每页大小（pageSize）

    返回值:
    - 返回一个包含查询结果列表和总数的响应对象
    """

    try:
        # 分页查询参数解析
        page = int(request.json["page"])
        page_size = int(request.json["pageSize"])
        phone_name = request.json.get("phone_name", 0)
        phone_status = request.json.get("phone_status", 0)
        usephone_user_name = request.json.get("usephone_user_name", 0)
        with application.app_context():
            filter_list = []
            # 筛选条件拓展点
            # 代码示例：
            # yyyy = request.json["xxxx"]
            # if len(yyyy) > 0 :
            #    filter_list.append(Model.属性.like(f"%{yyyy}%"))
            # =====结束
            # 执行数据库查询
            if len(usephone_user_name) > 0:
                filter_list.append(Phone.usephone_user_name.like(f"%{usephone_user_name}%"))
            if len(phone_status) > 0:
                filter_list.append(Phone.phone_status.like(f"%{phone_status}%"))
            if len(phone_name) > 0:
                filter_list.append(Phone.phone_name.like(f"%{phone_name}%"))
            datas = module_model.query.filter(*filter_list).limit(page_size).offset((page - 1) * page_size).all()
            total = module_model.query.filter(*filter_list).count()
            return respModel().ok_resp_list(lst=datas, total=total)
    except Exception as e:
        print(e)
        return respModel.error_resp(f"服务器错误,请联系管理员:{e}")


@module_route.route(f"/{module_name}/queryById", methods=["GET"])
def queryById():
    """
    查询数据(单条记录)

    参数:
    - 通过查询参数接收记录ID（id）

    返回值:
    - 返回查询到的单条数据或无数据的提示响应对象
    """

    try:
        data_id = int(request.args.get("id"))
        with application.app_context():
            # 根据ID查询数据
            data = module_model.query.filter_by(id=data_id).first()
        if data:
            return respModel().ok_resp(obj=data)
        else:
            return respModel.ok_resp(msg="查询成功,但是没有数据")
    except Exception as e:
        print(e)
        return respModel.error_resp(f"服务器错误,请联系管理员:{e}")


@module_route.route(f"/{module_name}/insert", methods=["POST"])
def insert():
    """
    新增数据

    参数:
    - 通过请求体（JSON）接收数据字段

    返回值:
    - 返回添加结果的响应对象，包含新增记录的ID
    """

    try:
        with application.app_context():
            # 设置ID为None以触发自增长
            data = module_model(**request.json, change_time=datetime.strftime(datetime.today(), '%Y-%m-%d %H:%M:%S'))
            database.session.add(data)
            # 提交后获取新增数据的ID
            database.session.flush()
            data_id = data.id
            database.session.commit()
        return respModel.ok_resp(msg="添加成功", dic_t={"id": data_id})
    except Exception as e:
        return respModel.error_resp(msg=f"添加失败:{e}")


@module_route.route(f"/{module_name}/update", methods=["PUT"])
def update():
    """
    修改数据

    参数:
    - 通过请求体（JSON）接收需要修改的数据字段，包括ID

    返回值:
    - 返回修改结果的响应对象
    """

    try:
        with application.app_context():
            filter_list = []
            change_user = request.json.get("user", 0)
            data_user = module_model.query.filter_by(id=request.json["id"]).first()
            if change_user != data_user.usephone_user_name:
                data_user.phone_status = "已借出"

            # 根据ID更新数据
            # if len(change_user) > 0:
            #     module_model.query.filter_by(id=request.json["id"]).update({"usephone_user_name": change_user})
            module_model.query.filter_by(id=request.json["id"]).update(request.json)
            module_model.query.filter_by(id=request.json["id"]).update({"phone_status": data_user.phone_status})
            module_model.query.filter_by(id=request.json["id"]).update(
                {"change_time": datetime.strftime(datetime.today(), '%Y-%m-%d %H:%M:%S')})
            database.session.commit()
        return respModel.ok_resp(msg="修改成功")
    except Exception as e:
        print(e)
        return respModel.error_resp(msg=f"修改失败，请联系管理员:{e}")


@module_route.route(f"/{module_name}/delete", methods=["DELETE"])
def delete():
    """
    删除数据

    参数:
    - 通过查询参数接收要删除的记录ID

    返回值:
    - 返回删除结果的响应对象
    """

    try:
        with application.app_context():
            # 根据ID删除记录
            module_model.query.filter_by(id=request.args.get("id")).delete()
            database.session.commit()
        return respModel.ok_resp(msg="删除成功")
    except Exception as e:
        print(e)
        return respModel.error_resp(msg=f"服务器错误,删除失败：{e}")


@module_route.route(f"/{module_name}/queryAll", methods=["GET"])
def queryAll():
    try:
        with application.app_context():

            datas = module_model.query.all()

        return respModel.ok_resp_list(lst=datas, msg="查询成功")
    except Exception as e:
        print(e)
        return respModel.error_resp(msg=f"服务器错误：{e}")


@module_route.route(f"/{module_name}/updatePhoneStatus", methods=["PUT"])
def updatePhoneStatus():
    """
    修改数据

    参数:
    - 通过请求体（JSON）接收需要修改的数据字段，包括ID

    返回值:
    - 返回修改结果的响应对象
    """

    try:

        with application.app_context():
            # 根据ID更新数据
            module_model.query.filter_by(id=request.json["id"]).update(
                {"phone_status": "未借出", "usephone_user_name": "周永峰"})
            database.session.commit()
        return respModel.ok_resp(msg="修改成功")
    except Exception as e:
        print(e)
        return respModel.error_resp(msg=f"修改失败，请联系管理员:{e}")
