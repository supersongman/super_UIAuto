from app import database


class Phone(database.Model):
    __tablename__ = "t_phone"
    id = database.Column(database.Integer, primary_key=True, comment='手机编号',autoincrement=True)
    phone_name = database.Column(database.String(255), comment='手机名称')
    phone_status = database.Column(database.String(255), comment='手机状态')
    usephone_user_name = database.Column(database.String(255), comment='当前手机使用人')
    change_time = database.Column(database.DateTime, unique=True, comment='借用时间')
