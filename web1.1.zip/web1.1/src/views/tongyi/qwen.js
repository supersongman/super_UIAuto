import axios from "~/axios"

// 模块名 - 和后台对应
const module_name = "qwen"

// 标准 - 增删改查接口调用
// export function qwen(data) {
//     return axios.post(`/${module_name}/qwen`, data)
// }

// 拓展其他方法

export async function qwen(data) {
    try {
      const response = await axios.post(`/${module_name}/qwen`, data);
      return response;
    } catch (error) {
      throw new Error(`Request failed with status code ${error.response.status}`);
    }
  }