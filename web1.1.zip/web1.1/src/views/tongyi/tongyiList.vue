<template>
    <div>
        <h1>通义灵码对话界面</h1>
        <textarea v-model="question" placeholder="请输入你的问题..." rows="4"></textarea>
        <button @click="askQuestion">提问</button>
        <div v-if="answer">
            <h2>回答:</h2>
            <p>{{ answer }}</p>
        </div>
    </div>
</template>

<script lang="ts" setup>
import { qwen } from './qwen.js'; // 直接导入qwen函数
import { ref } from 'vue';
const question = ref('');
const answer = ref('');

const askQuestion = async () => {
    try {
        // 直接调用qwen函数
        const response = await qwen({ question: question.value });
        console.log('question:', question.value);
        answer.value = response.data.msg;
    } catch (error) {
        console.error('Error details:', error); // 打印错误详情
        answer.value = '请求失败，请稍后再试。';
    }
};


</script>