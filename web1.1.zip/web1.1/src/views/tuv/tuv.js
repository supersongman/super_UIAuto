import axios from "~/axios"

// 模块名 - 和后台对应
const module_name = "tuv"

// 标准 - 增删改查接口调用
export function queryByPage(data) {
    return axios.post(`/${module_name}/queryByPage`, data)
}

export function queryById(id) {
    return axios.get(`/${module_name}/queryById?id=${id}`)
}

export function insertData(data) {
    return axios.post(`/${module_name}/insert`, data)
}

export function updateData(data) {
    return axios.put(`/${module_name}/update`, data)
}

export function deleteData(id){
    return axios.delete(`/${module_name}/delete?id=${id}`)
}

// 拓展其他方法
// export function upLoad(data) {
//     return axios.post(`/${module_name}/upLoad`, data)
// }
// 异步调用
export async function upload_excel(data) {
    try {
        const response = await axios.post(`/${module_name}/upload_excel`, data);
        return response;
    } catch (error) {
        throw error; // 或者你可以在这里处理错误，例如记录错误日志
    }
}