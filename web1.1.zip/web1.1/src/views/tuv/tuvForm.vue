<template>
    <el-form ref="ruleFormRef" :model="ruleForm" :rules="rules" label-width="120px" class="demo-ruleForm"
        status-icon>
        <!-- 不同的页面，不同的表单字段 -->
        <el-form-item label="编号" prop="id">
            <el-input v-model="ruleForm.id" disabled/>
        </el-form-item>
        <el-form-item label="date" prop="date">
            <el-input v-model="ruleForm.date" />
        </el-form-item>
        <el-form-item label="supplier" prop="supplier">
            <el-input v-model="ruleForm.supplier" />
        </el-form-item>
        <el-form-item label="coutry" prop="coutry">
            <el-input v-model="ruleForm.coutry" />
        </el-form-item>
        <el-form-item label="certficate_type" prop="certficate_type">
            <el-input v-model="ruleForm.certficate_type" />
        </el-form-item>
        <el-form-item label="supplier_currency" prop="supplier_currency">
            <el-input v-model="ruleForm.supplier_currency" />
        </el-form-item>
        <el-form-item label="汇率换算" prop="huilvhuansuan">
            <el-input v-model="ruleForm.huilvhuansuan" />
        </el-form-item>
        <el-form-item label="supplier_cost" prop="supplier_cost">
            <el-input v-model="ruleForm.supplier_cost" />
        </el-form-item>
        <el-form-item label="workng_hours_fee" prop="workng_hours_fee">
            <el-input v-model="ruleForm.workng_hours_fee" />
        </el-form-item>
        <el-form-item label="total_coast" prop="total_coast">
            <el-input v-model="ruleForm.total_coast" />
        </el-form-item>
        <el-form-item label="to_sales_price" prop="to_sales_price">
            <el-input v-model="ruleForm.to_sales_price" />
        </el-form-item>
        <el-form-item label="Profit_margin" prop="Profit_margin">
            <el-input v-model="ruleForm.Profit_margin" />
        </el-form-item>
        <el-form-item label="分包率" prop="fenbaolv">
            <el-input v-model="ruleForm.fenbaolv" />
        </el-form-item>
        <el-form-item label="其他影响价格因素" prop="other_so_price">
            <el-input v-model="ruleForm.other_so_price" />
        </el-form-item>
        <el-form-item label="loadtime" prop="loadtime">
            <el-input v-model="ruleForm.loadtime" />
        </el-form-item>

        <el-form-item label="sample" prop="sample">
            <el-input v-model="ruleForm.sample" />
        </el-form-item>
        <el-form-item label="base_on_xx_report" prop="base_on_xx_report">
            <el-input v-model="ruleForm.base_on_xx_report" />
        </el-form-item>
        <el-form-item label="local_resresenttive" prop="local_resresenttive">
            <el-input v-model="ruleForm.local_resresenttive" />
        </el-form-item>
        <el-form-item label="model_name" prop="model_name">
            <el-input v-model="ruleForm.model_name" />
        </el-form-item>
        <el-form-item label="mode_type_is_vairas" prop="mode_type_is_vairas">
            <el-input v-model="ruleForm.mode_type_is_vairas" />
        </el-form-item>
        <el-form-item label="cerificate_validity" prop="cerificate_validity">
            <el-input v-model="ruleForm.cerificate_validity" />
        </el-form-item>

        <el-form-item label="remark" prop="remark">
            <el-input v-model="ruleForm.remark" />
        </el-form-item>
        <el-form-item label="remarkto" prop="remarkto">
            <el-input v-model="ruleForm.remarkto" />
        </el-form-item>
        <!-- 如果有不需要展示在页面的属性，建议通过 v-show="false" 进行控制，不要直接删除，这样方便你后续改来改去 -->
        <!-- END 表单字段 -->
        <!-- 表单操作 -->
        <el-form-item>
            <el-button type="primary" @click="submitForm(ruleFormRef)">
                提交
            </el-button>
            <el-button @click="resetForm(ruleFormRef)">清空</el-button>
            <el-button @click="closeForm()">关闭</el-button>
        </el-form-item>
        <!-- END 表单操作 -->
    </el-form>
</template>
  
<script lang="ts" setup>
import { ref, reactive } from "vue"
import { queryById, insertData, updateData } from './tuv' // 不同页面不同的接口
import type { FormInstance, FormRules } from 'element-plus'
import { useRouter } from "vue-router";
const router = useRouter()

// 表单实例
const ruleFormRef = ref<FormInstance>()
// 表单数据 - 不同的页面，不同的表单字段
const ruleForm = reactive({
    id: 0,
    date: '',
    supplier: '',
    coutry: '',
    certficate_type: '',
    supplier_currency: '',
    huilvhuansuan: '',
    supplier_cost: '',
    workng_hours_fee: '',
    total_coast: '',
    to_sales_price: '',
    Profit_margin: '',
    fenbaolv: '',
    other_so_price: '',
    loadtime: '',
    sample: '',
    base_on_xx_report: '',
    local_resresenttive: '',
    model_name: '',
    mode_type_is_vairas: '',
    cerificate_validity: '',
    remark: '',
    remarkto: '',

})

// 表单验证规则 - 不同的页面，不同的校验规则
const rules = reactive<any>({
    coutry: [
        { required: true, message: '必填项', trigger: 'blur' }
    ]
})
// 提交表单
const submitForm = async (form: FormInstance | undefined) => {
    if (!form) return
    await form.validate((valid, fields) => {
        if (!valid) {
            return 
        } 
        // 有ID 代表是修改， 没ID 代表是新增
        if (ruleForm.id > 0) {
            updateData(ruleForm).then((res: { data: { code: number; msg: string; }; }) => {
                if (res.data.code == 200) {
                    router.push('/tuvList') // 跳转回列表页面 - 不同的页面，不同的路径
                }
            })
        } else {
            insertData(ruleForm).then((res: { data: { code: number; msg: string; }; }) => {
                if (res.data.code == 200) {
                    router.push('/tuvList') // 跳转回列表页面 - 不同的页面，不同的路径
                }
            })
        }
    })
}
// 重置表单
const resetForm = (form: FormInstance | undefined) => {
    if (!form) return
    form.resetFields()
}
// 关闭表单 - 回到数据列表页 - 不同的页面，不同的路径
const closeForm = () => {
    router.push('/tuvList')
}
// 加载表单数据
const loadData = async (id: number) => {
    const res = await queryById(id)
    // 不同的页面，不同的表单字段 (注意这里的res.data.data.xxx，xxx是接口返回的字段，不同的接口，字段不同)
    ruleForm.id = res.data.data.id
    ruleForm.date = res.data.data.date
    ruleForm.supplier = res.data.data.supplier
    ruleForm.coutry = res.data.data.coutry
    ruleForm.certficate_type = res.data.data.certficate_type
    ruleForm.supplier_currency= res.data.data.supplier_currency
    ruleForm.huilvhuansuan = res.data.data.huilvhuansuan
    ruleForm.supplier_cost = res.data.data.supplier_cost
    ruleForm.workng_hours_fee = res.data.data.workng_hours_fee
    ruleForm.total_coast = res.data.data.total_coast
    ruleForm.to_sales_price = res.data.data.to_sales_price
    ruleForm. Profit_margin= res.data.data.Profit_margin
    ruleForm.fenbaolv = res.data.data.fenbaolv
    ruleForm.other_so_price= res.data.data.other_so_price
    ruleForm.loadtime = res.data.data.loadtime
    ruleForm.sample = res.data.data.sample
    ruleForm.base_on_xx_report = res.data.data.base_on_xx_report
    ruleForm.local_resresenttive = res.data.data.local_resresenttive
    ruleForm.model_name= res.data.data.model_name
    ruleForm.mode_type_is_vairas = res.data.data.mode_type_is_vairas
    ruleForm.cerificate_validity = res.data.data.cerificate_validity
    ruleForm.remark = res.data.data.remark
    ruleForm.remarkto = res.data.data.remarkto

}

// 如果有id参数，说明是编辑，需要获取数据
console.log(router)
let query_id = router.currentRoute.value.query.id
ruleForm.id = query_id ? Number(query_id) : 0
if (ruleForm.id > 0) {
    loadData(ruleForm.id)
}
// 其他逻辑

</script>
  

