<template>
    <!-- 搜索表单 -->
    <el-form ref="searchFormRef" :inline="true" :model="searchForm" class="demo-form-inline">
        <el-form-item label="手机名称">
            <el-input v-model="searchForm.phone_name" placeholder="根据手机名称筛选" clearable />
        </el-form-item>
        <el-form-item label="当前手机使用人">

            <el-input v-model="searchForm.usephone_user_name" placeholder="根据当前手机使用人筛选" clearable />

        </el-form-item>

        <!-- <el-form-item label="手机状态" prop="phone_status">
            <el-select v-model="searchForm.phone_status" placeholder="根据手机状态筛选" clearable>
    
                <el-option v-for="project in projectList" :key="project.id" :label="project.phone_status"
                    :value="project.id" />
            </el-select>
        </el-form-item> -->
        <el-form-item label="手机状态" prop="phone_status">
            <el-select v-model="searchForm.phone_status" placeholder="请选择手机状态" clearable>
                <el-option label="未借出" value="未借出" />
                <el-option label="已借出" value="已借出" />
            </el-select>
        </el-form-item>
        <el-row class="mb-4" type="flex" justify="end"> <!-- 居右 type="flex" justify="end" -->
            <el-button type="primary" @click="loadData()">查询</el-button>
            <el-button type="warning" @click="onDataForm(-1)">新增数据</el-button>
        </el-row>
    </el-form>
    <!-- END 搜索表单 -->
    <!-- 数据表格 -->
    <el-table :data="tableData" style="width: 100%;" max-height="500">
        <!-- 数据列 -->
        <!-- 默认情况下，如果单元格内容过长，会占用多行显示。 若需要单行显示可以使用 show-overflow-tooltip -->
        <el-table-column v-for="col in columnList" :prop="col.prop" :label="col.label" :key="col.prop"
            show-overflow-tooltip="true" />
        <!-- 操作 -->
        <!-- <el-table-column fixed="right" label="操作">
            <template #default="scope">
                <el-button link type="primary" size="small" @click.prevent="onDataForm(scope.$index)">
                    借手机
                </el-button>
                <el-button link type="primary" size="small" @click.prevent="onDelete(scope.$index)">
                    删除
                </el-button>
                <el-button link type="primary" size="small" @click.prevent="onUpdata(scope.$index)">
                    还手机
                </el-button>
            </template>
</el-table-column> -->
        <el-table-column fixed="right" label="操作">
            
            <template #default="scope">
                <el-button link type="primary" size="small" @click.prevent="onDataForm(scope.$index)">
                    编辑手机
                </el-button>
                <template v-if="scope.row.phone_status === '未借出'">
                    <el-button link type="primary" size="small" @click.prevent="onDataForm(scope.$index)">
                        借手机
                    </el-button>
                </template>
                <template v-else-if="scope.row.phone_status === '已借出'">
                    <el-button link type="primary" size="small" @click.prevent="onUpdata(scope.$index)">
                        还手机
                    </el-button>
                </template>
                <el-button link type="primary" size="small" @click.prevent="onDelete(scope.$index)">
                    删除
                </el-button>
                <!-- 使用 v-if 和 v-else 控制按钮的显示 -->

            </template>
        </el-table-column>
    </el-table>
    <!-- 分页 -->
    <div class="demo-pagination-block">
        <div class="demonstration"></div>
        <el-pagination v-model:current-page="currentPage" v-model:page-size="pageSize" :page-sizes="[10, 20, 30, 50]"
            layout="total, sizes, prev, pager, next, jumper" :total="total" @size-change="handleSizeChange"
            @current-change="handleCurrentChange" />
    </div>
    <!-- END 分页 -->
</template>

<script lang="ts" setup>
import { ref, reactive } from "vue"
import { queryByPage, deleteData, updateData, updatePhoneStatus } from './phone' // 不同页面不同的接口
import { useRouter } from "vue-router";
const router = useRouter()

// 分页参数
const currentPage = ref(1)
const pageSize = ref(10)
const total = ref(0)

// 搜索功能 - 筛选表单
const searchForm = reactive({ id: "", "phone_name": "", "usephone_user_name": "", "phone_status": "" })

// 表格列 - 不同页面不同的列
const columnList = ref([
    { prop: "id", label: '手机ID' },
    { prop: "phone_name", label: '手机名称' },
    { prop: "phone_status", label: '手机状态' },
    { prop: "usephone_user_name", label: '当前手机使用人' },
    { prop: "change_time", label: '借用时间' }
])
// 表格数据
const tableData = ref([])

// 加载页面数据
const loadData = () => {
    let searchData = searchForm
    searchData["page"] = currentPage.value
    searchData["pageSize"] = pageSize.value

    queryByPage(searchData).then((res: { data: { data: never[]; total: number; msg: string }; }) => {
        tableData.value = res.data.data
        total.value = res.data.total
    })
}
loadData()

// 变更 页大小
const handleSizeChange = (val: number) => {
    console.log("页大小变化:" + val)
    pageSize.value = val
    loadData()
}
// 变更 页码
const handleCurrentChange = (val: number) => {
    console.log("页码变化:" + val)
    currentPage.value = val
    loadData()
}
const projectList = ref([{
    phone_status: '',

}]);

// function getProjectList() {
//     queryAllPhone().then((res) => {
//     projectList.value = res.data.data;
//     console.log("h哈哈哈哈哈哈哈哈",projectList.value);
//   });
// }
// getProjectList();

// // 打开表单 （编辑/新增）
// const onDataForm = (index: number) => {
//     let params_data = {}
//     if (index >= 0) {
//         params_data = {
//             id: tableData.value[index]["id"]
//         }
//     }
//     router.push({
//         path: 'phoneForm', // 不同页面不同的表单路径
//         query: params_data
//     });
// }



// 打开表单 （编辑/新增）
// const onDataForm = (index: number) => {
//     let path = 'phoneForm';
//     const params_data = {}
//     // 如果索引小于0，表示是新增操作，修改路径为插入表单的路径
//     if (index < 0) {
//         path = 'insertPhoneForm';
//     } else {
//         // 编辑操作，准备参数数据

//         const params_data = {
//             id: tableData.value[index]["id"]
//         };
//     }

//     // 根据操作类型（编辑或新增）推进到相应的表单页面
// router.push({
//     path: path,
//     query: params_data // 只有编辑时才传递参数
//     });
// }
// 打开表单 （编辑/新增）
const onDataForm = (index: number) => {
    let path = 'phoneForm';
    let params_data = {}; // 初始化为空对象

    // 如果索引有效（即大于等于0），说明是编辑操作，准备参数并设置路径为编辑表单
    if (index >= 0) {
        path = 'phoneForm';
        params_data = {
            id: tableData.value[index]["id"]
        };
    } else { // 索引小于0视为新增操作，设置路径为新增表单
        path = 'insertPhoneForm';
    }

    // 推进到相应的表单页面，只有在params_data有内容时才附加query参数
    router.push({
        path: path,
        query: Object.keys(params_data).length > 0 ? params_data : undefined
    });
}




// 删除数据
const onDelete = (index: number) => {
    deleteData(tableData.value[index]["id"]).then((res: {}) => {
        loadData()
    })
}
//还手机

const onUpdata = (index: number) => {
    updatePhoneStatus({
        id: tableData.value[index]["id"],

    }).then((res: { data: { code: number; msg: string; }; }) => {
        if (res.data.code == 200) {
            loadData()// 重新加载页面
        }
    })
}



// 其他功能拓展

</script>
<style scoped>
.demo-pagination-block+.demo-pagination-block {
    margin-top: 10px;
}

.demo-pagination-block .demonstration {
    margin-bottom: 16px;
}
</style>