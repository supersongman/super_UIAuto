# -*- coding: UTF-8 -*-
# --示例代码--请根据需要编写
from selenium import webdriver  # 引入浏览器驱动对象
from selenium.webdriver import ActionChains

from webrun.core.globalContext import g_context  # 引入全局变量
import allure  # 引入allure

import os
import shutil
import glob


def rename_and_move_zip_files(source_directory, target_directory, new_prefix="new_"):
    # 确保目标文件夹存在
    if not os.path.exists(target_directory):
        os.makedirs(target_directory)

    # 获取源文件夹中所有 .zip 文件
    zip_files = glob.glob(os.path.join(source_directory, '*.zip'))

    for zip_file in zip_files:
        # 获取文件名和文件路径
        file_name = os.path.basename(zip_file)
        file_extension = os.path.splitext(file_name)[1]  # 获取文件扩展名
        base_name = os.path.splitext(file_name)[0]  # 获取文件名（不包括扩展名）

        # 修改文件名
        new_file_name = f"{new_prefix}{base_name}{file_extension}"
        new_file_path = os.path.join(target_directory, new_file_name)

        # 移动文件并重命名
        shutil.move(zip_file, new_file_path)
        print(f"Moved and renamed: {zip_file} -> {new_file_path}")


# 示例用法
source_directory = '/path/to/source/folder'  # 替换为你的源文件夹路径
target_directory = '/path/to/target/folder'  # 替换为你的目标文件夹路径
new_prefix = "renamed_"  # 新文件名前缀

rename_and_move_zip_files(source_directory, target_directory, new_prefix)
{"goog:chromeOptions": {
    "args": [
        "--disable-bluetooth"
    ]
}
}
