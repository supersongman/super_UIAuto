"""
excel相关操作
"""
import pandas as pd
import yaml
from collections import OrderedDict
from ruamel.yaml import YAML


class ReadExcel():
    def __init__(self):
        pass

    def get_all_data(self, path, sheetname):
        # 读取 Excel 文件
        df = pd.read_excel(path, sheet_name=sheetname, usecols=range(3, 14), skiprows=1, header=0)

        # 获取表头
        data_title = df.columns.tolist()

        # 存储数据
        data = []
        for index, row in df.iterrows():
            filtered_row = [row[col] for col in data_title]
            data.append(dict(zip(data_title, filtered_row)))
        # print(data)
        return data

    def write_exceldata_yaml(self, yaml_path, excel_path, sheetname):
        yaml = YAML()
        yaml.default_flow_style = False
        yaml.sort_keys = False

        datas = self.get_all_data(excel_path, sheetname)
        print(f"Datas: {datas}")  # 添加调试信息

        # 读取现有的 YAML 文件内容
        try:
            with open(yaml_path, 'r', encoding='utf-8') as file:
                existing_data = yaml.load(file)
        except FileNotFoundError:
            existing_data = {}
            # 确保 existing_data 是一个字典
        except Exception as exc:
            print(f"Error reading YAML file: {exc}")
            existing_data = {}

        # 初始化 ddts 列表
        if "ddts" not in existing_data:
            existing_data["ddts"] = []

        # 处理 datas 中的每个元素
        for ddt_data in datas:
            print(f"DDT Data: {ddt_data}")  # 添加调试信息
            if isinstance(ddt_data, dict):
                # 直接将 ddt_data 添加到 ddts 列表中
                existing_data["ddts"].append(ddt_data)
            else:
                print(f"Unexpected data type: {type(ddt_data)}")

        # 写入更新后的数据到 YAML 文件
        with open(yaml_path, 'w', encoding='utf-8') as file:
            yaml.dump(existing_data, file)


if __name__ == "__main__":
    file_path = "/Users/mac/Documents/自动化平台搭建/auto-data/HOOS验证记录表.xlsx"
    sheet_name = "Airbus TO"
    yaml_path = "/Users/mac/Documents/自动化平台搭建/auto-data/ui_yaml/a/1_908bbb4b-ffff-475a-b193-d77b98e690cf.yaml"
    reader = ReadExcel()
    # reader.write_exceldata_yaml(yaml_path, file_path, sheet_name)
    reader.get_all_data(file_path, sheet_name)
#
# r = ReadExcel()
# r.get_all_data("/Users/mac/Documents/自动化平台搭建/auto-data/HOOS验证记录表.xlsx", "AirbusTO")
