class g_context(object):  # 类继承
    # _dic = {}  # 内置属性，外部不可修改
    _instance = None
    _dic = {}

    @staticmethod
    def get_instance():
        if g_context._instance is None:
            g_context._instance = g_context()
        return g_context._instance

    def set_dict(self, key, value):
        # 给字典添加对应的值
        self._dic[key] = value

    def get_dict(self, key):
        # 获取字典当中某个key的value，如果没有值则返回None
        return self._dic.get(key, None)

    def set_by_dict(self, dic):
        # 设置字典中的值，以键值对的方式更新
        self._dic.update(dic)

    def show_dict(self):
        # 显示当前字典的所有的数据
        return self._dic

    def get_dict(self, key):
        # 获取字典当中某个key的value，如果没有值则返回None
        return self._dic.get(key, None)

    def __getattr__(self, name):
        return self._dic.get(name)

    def __setattr__(self, name, value):
        if name in ["_instance", "_dic"]:
            super().__setattr__(name, value)
        else:
            self._dic[name] = value

# class g_context(object):
#     _instance = None
#     _dic = {}
#
#     @staticmethod
#     def get_instance():
#         if g_context._instance is None:
#             g_context._instance = g_context()
#         return g_context._instance
#
#     def set_by_dict(self, dic):
#         self._dic.update(dic)
#
#     def __getattr__(self, name):
#         return self._dic.get(name)
#
#     def __setattr__(self, name, value):
#         self._dic[name] = value
#
#     def show_dict(self):
#         return self._dic
#
#     def set_dict(self, key, value):
#         # 给字典添加对应的值
#         self._dic[key] = value
#
#     def get_dict(self, key):
#         # 获取字典当中某个key的value，如果没有值则返回None
#         return self._dic.get(key, None)
