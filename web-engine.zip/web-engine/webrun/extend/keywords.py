import time

from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.remote.webdriver import WebDriver
from selenium.webdriver.support import expected_conditions as EC
import allure
from webrun.core.globalContext import g_context
import pymysql
from pymysql import cursors
import os
import datetime
import hashlib
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
import shutil
from datetime import date
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from datetime import date
import glob



class Keywords:
    driver = None

    def __init__(self, webdriver: WebDriver, **kwargs):
        self.driver = webdriver
        self.action = ActionChains(webdriver)

    # 浏览器操作- 打开浏览器
    def open_browser(self, **kwargs):
        self.driver.get(kwargs["数据内容"])

    # 浏览器操作- 关闭浏览器
    def quit_browser(self, **kwargs):
        self.driver.quit()

    # 浏览器操作- 关闭当前窗口
    def close_browser(self, **kwargs):
        self.driver.close()

    # 浏览器操作- 最大化当前窗口
    def maximized_browser(self, **kwargs):
        self.driver.maximize_window()

    # 元素操作-输入内容
    def input_context(self, **kwargs):
        self.driver.find_element(kwargs["定位方式"], kwargs["目标对象"]).send_keys(kwargs["数据内容"])

    # 元素操作-点击元素
    def option_click(self, **kwargs):
        self.driver.find_element(kwargs["定位方式"], kwargs["目标对象"]).click()

    #
    def get_text(self, **kwargs):
        text = self.driver.find_element(kwargs["定位方式"], kwargs["目标对象"]).text

        print("开始获取元素开始获取元素开始获取元素开始获取元素开始获取元素开始获取元素开始获取元素开始获取元素开始获取元素开始获取元素开始获取元素开始获取元素开始获取元素开始获取元素")
        # 设置全局上下文中的 text 属性
        g_context().set_by_dict({"text": text})
        # 获取并打印全局上下文中的 text 属性
        print("页面元素的text文本是：", g_context().text)
        # 3. 将文本写入到 txt 文件中
        # 生成唯一的文件名
        timestamp = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
        file_name = f"text_output_{timestamp}.txt"
        file_path = os.path.join(os.getcwd(), file_name)
        with open(file_path, "w", encoding="utf-8") as file:
            file.write(text)
        print(f"文本已写入到文件：{file_path}")

    # 等待-强制等待
    def wait_sleep(self, **kwargs):
        time.sleep(int(kwargs["数据内容"]))

    # 等待-隐式等待
    def im_sleep(self, **kwargs):
        self.driver.implicitly_wait(int(kwargs["数据内容"]))

    # 等待-显示等待
    def ec_sleep(self, **kwargs):
        wait = WebDriverWait(self.driver, int(kwargs["数据内容"]))
        element = wait.until(EC.element_to_be_clickable((kwargs["定位方式"], kwargs["目标对象"])))

    # 断言处理 - 断言浏览器标题
    def assert_title(self, **kwargs):
        assert EC.title_is(kwargs["数据内容"])(self.driver)

    # 断言处理 - 断言当前Url
    def assert_url(self, **kwargs):
        assert EC.url_to_be(kwargs["数据内容"])(self.driver)

    # 断言处理 - 相等
    # def assert_text_eql(self,**kwargs):
    #     # 预期值
    #     target = kwargs["数据内容"]
    #     # 当前值
    #     current = self.driver.find_element(kwargs["定位方式"], kwargs["目标对象"]).text
    #     print(f"判断是否相等,{target} - {current}")
    #     assert current == target

    # 断言处理 - 不相等
    def assert_text_noeql(self, **kwargs):
        assert self.driver.find_element(kwargs["定位方式"], kwargs["目标对象"]).text != kwargs["数据内容"]

    # 断言处理 - 包含
    def assert_text_in(self, **kwargs):
        assert kwargs["数据内容"] in self.driver.find_element(kwargs["定位方式"], kwargs["目标对象"]).text

    # 断言处理 - 大于
    def assert_text_gre(self, **kwargs):
        assert self.driver.find_element(kwargs["定位方式"], kwargs["目标对象"]).text > kwargs["数据内容"]

    # 断言处理 - 小于
    def assert_text_less(self, **kwargs):
        assert self.driver.find_element(kwargs["定位方式"], kwargs["目标对象"]).text < kwargs["数据内容"]

    # 断言处理 - 不包含
    def assert_text_notin(self, **kwargs):
        assert kwargs["数据内容"] not in self.driver.find_elements(kwargs["定位方式"], kwargs["目标对象"])

    def shoot_image(self):
        time.sleep(1)
        allure.attach(self.driver.get_screenshot_as_png(), "截图快照", allure.attachment_type.PNG)  # 截图

    def create_directory(self, **kwargs):  # 方法名称 必须与关键字名称一致

        try:
            # 创建目录
            os.makedirs(kwargs["路径"], exist_ok=True)
            print(f"已创建成功")
        except OSError as e:
            print(f"创建目录失败: {e}")

    def input_content_ex(self, **kwargs):
        key = hashlib.md5(str(kwargs["_页面元素"]).encode()).hexdigest()  # # 从全局变量获取对应的元素
        all_ele_data = g_context().get_dict("_page_element")
        ele_data = all_ele_data[key]
        self.driver.find_element(ele_data["定位方式"], ele_data["目标对象"]).send_keys(kwargs["数据内容"])

    def mysql_sql_exec(self, **kwargs):
        print("执行SQL:", kwargs["sql语句"])
        import pymysql
        from pymysql import cursors
        config = {"cursorclass": cursors.DictCursor}
        # 读取全局变量 - 根据选择的数据 读取指定的数据库配置 连接对应的数据库
        db_config = g_context().get_dict("_database")[kwargs["数据库"]]
        config.update(db_config)
        con = pymysql.connect(**config)
        cur = con.cursor()
        cur.execute(kwargs["sql语句"])
        rs = cur.fetchall()
        cur.close()
        con.close()
        print("数据库查询结果:", rs)

        var_names = kwargs["引用变量"]
        result = {}
        for i, data in enumerate(rs, start=1):
            for j, value in enumerate(var_names):
                result[f'{var_names[j]}_{i}'] = data.get(var_names[j])  # 根据变量名称找读取出来的内容
        print("数据库拿到的数据是：", result)
        g_context().set_by_dict(result)

    def mysql_query_exec(self, **kwargs):
        da_config = g_context().get_dict("_database")[kwargs["数据库"]]
        config = {
            "host": da_config["host"],
            "port": da_config["port"],
            "user": da_config["username"],
            "password": da_config["password"],
            "database": da_config["database"],
            "cursorclass": cursors.DictCursor}
        con = pymysql.connect(**config)
        cur = con.cursor()
        cur.execute(kwargs["sql语句"])
        rs = cur.fetchall()
        cur.close()
        con.close()
        print("数据库查询结果:", rs)
        # 遍历生成对应的数据
        var_names = kwargs["引用变量"].split(",")
        result = {}
        for i, data in enumerate(rs, start=1):
            for j, value in enumerate(var_names):
                result[f'{var_names[j]}_{i}'] = data.get(var_names[j])  # 根据变量名找对应的数据

        # 对应的数据写到全局变量中
        g_context().set_by_dict(result)
        print("全局变量数据是：", g_context.show_dict())

    def mouse_actions(self, **kwargs):
        try:
            # 移动到指定坐标并点击
            self.action.move_by_offset(kwargs["x"], kwargs['y']).click().perform()

            # 重置鼠标位置
            # self.action.move_by_offset(kwargs["x"], kwargs['y']).perform()

        except Exception as e:
            print(f"发生错误: {e}")
            raise

    def keyboardActions(self, **kwargs):
        try:
            # 发送向下箭头键

            self.action.send_keys(Keys.ARROW_DOWN).perform()
            time.sleep(0.5)  # 可选：等待0.5秒，确保每次按键生效

            # 发送回车键
            self.action.send_keys(Keys.RETURN).perform()

        except Exception as e:
            print(f"发生错误: {e}")
            raise

    def doublekeyboardActions(self, **kwargs):
        try:
            # 发送向下箭头键

            self.action.send_keys(Keys.ARROW_DOWN).perform()
            time.sleep(0.5)  # 可选：等待0.5秒，确保每次按键生效
            self.action.send_keys(Keys.ARROW_DOWN).perform()
            time.sleep(0.5)  # 可选：等待0.5秒，确保每次按键生效
            # 发送回车键
            self.action.send_keys(Keys.RETURN).perform()

        except Exception as e:
            print(f"发生错误: {e}")
            raise

    def troublekeyboardActions(self, **kwargs):
        try:
            # 发送向下箭头键

            self.action.send_keys(Keys.ARROW_DOWN).perform()
            time.sleep(0.5)  # 可选：等待0.5秒，确保每次按键生效
            self.action.send_keys(Keys.ARROW_DOWN).perform()
            time.sleep(0.5)  # 可选：等待0.5秒，确保每次按键生效
            self.action.send_keys(Keys.ARROW_DOWN).perform()
            time.sleep(0.5)  # 可选：等待0.5秒，确保每次按键生效
            # 发送回车键
            self.action.send_keys(Keys.RETURN).perform()

        except Exception as e:
            print(f"发生错误: {e}")
            raise

    def ifRWY_COND(self, **kwargs):
        try:
            # 发送向下箭头键
            if kwargs["RWY_COND"] == "1-POOR":
                self.action.send_keys(Keys.ARROW_DOWN).perform()
                time.sleep(0.5)  # 可选：等待0.5秒，确保每次按键生效
            elif kwargs["RWY_COND"] == "2-MEDIUM FOR POOR":
                self.action.send_keys(Keys.ARROW_DOWN).perform()
                time.sleep(0.5)  # 可选：等待0.5秒，确保每次按键生效
                self.action.send_keys(Keys.ARROW_DOWN).perform()
            elif kwargs["RWY_COND"] == "3-MEDIUM":
                self.action.send_keys(Keys.ARROW_DOWN).perform()
                time.sleep(0.5)  # 可选：等待0.5秒，确保每次按键生效
                self.action.send_keys(Keys.ARROW_DOWN).perform()
                time.sleep(0.5)  # 可选：等待0.5秒，确保每次按键生效
                self.action.send_keys(Keys.ARROW_DOWN).perform()
            elif kwargs["RWY_COND"] == "4-GOOD TO MEDIUM":
                self.action.send_keys(Keys.ARROW_DOWN).perform()
                time.sleep(0.5)  # 可选：等待0.5秒，确保每次按键生效
                self.action.send_keys(Keys.ARROW_DOWN).perform()
                time.sleep(0.5)  # 可选：等待0.5秒，确保每次按键生效
                self.action.send_keys(Keys.ARROW_DOWN).perform()
                time.sleep(0.5)  # 可选：等待0.5秒，确保每次按键生效
                self.action.send_keys(Keys.ARROW_DOWN).perform()
                time.sleep(0.5)  # 可选：等待0.5秒，确保每次按键生效
            elif kwargs["RWY_COND"] == "5-GOOD":
                self.action.send_keys(Keys.ARROW_DOWN).perform()
                time.sleep(0.5)  # 可选：等待0.5秒，确保每次按键生效
                self.action.send_keys(Keys.ARROW_DOWN).perform()
                time.sleep(0.5)  # 可选：等待0.5秒，确保每次按键生效
                self.action.send_keys(Keys.ARROW_DOWN).perform()
                time.sleep(0.5)  # 可选：等待0.5秒，确保每次按键生效
                self.action.send_keys(Keys.ARROW_DOWN).perform()
                time.sleep(0.5)  # 可选：等待0.5秒，确保每次按键生效
                self.action.send_keys(Keys.ARROW_DOWN).perform()
                time.sleep(0.5)  # 可选：等待0.5秒，确保每次按键生效
            elif kwargs["RWY_COND"] == "6-DRY":
                self.action.send_keys(Keys.ARROW_DOWN).perform()
                time.sleep(0.5)  # 可选：等待0.5秒，确保每次按键生效
                self.action.send_keys(Keys.ARROW_DOWN).perform()
                time.sleep(0.5)  # 可选：等待0.5秒，确保每次按键生效
                self.action.send_keys(Keys.ARROW_DOWN).perform()
                time.sleep(0.5)  # 可选：等待0.5秒，确保每次按键生效
                self.action.send_keys(Keys.ARROW_DOWN).perform()
                time.sleep(0.5)  # 可选：等待0.5秒，确保每次按键生效
                self.action.send_keys(Keys.ARROW_DOWN).perform()
                time.sleep(0.5)  # 可选：等待0.5秒，确保每次按键生效
                self.action.send_keys(Keys.ARROW_DOWN).perform()
                time.sleep(0.5)  # 可选：等待0.5秒，确保每次按键生效
            # 发送回车键
            self.action.send_keys(Keys.RETURN).perform()

        except Exception as e:
            print(f"发生错误: {e}")
            raise

    def ifLDG_CONF(self, **kwargs):
        try:
            # 发送向下箭头键
            if kwargs["APP_CONF"] == "5" and kwargs["LDG_CONF"] == "25":
                self.action.send_keys(Keys.ARROW_DOWN).perform()
                time.sleep(0.5)  # 可选：等待0.5秒，确保每次按键生效
                self.action.send_keys(Keys.ARROW_DOWN).perform()
            elif kwargs["APP_CONF"] == "5" and kwargs["LDG_CONF"] == "30":
                self.action.send_keys(Keys.ARROW_DOWN).perform()
            elif kwargs["APP_CONF"] == "20" and kwargs["LDG_CONF"] == "25":
                self.action.send_keys(Keys.ARROW_DOWN).perform()
                time.sleep(0.5)  # 可选：等待0.5秒，确保每次按键生效
                self.action.send_keys(Keys.ARROW_DOWN).perform()
            elif kwargs["APP_CONF"] == "20" and kwargs["LDG_CONF"] == "30":
                self.action.send_keys(Keys.ARROW_DOWN).perform()
            # 发送回车键
            self.action.send_keys(Keys.RETURN).perform()

        except Exception as e:
            print(f"发生错误: {e}")
            raise

    def compress_folder_to_zip(self, **kwargs):
        """
        将指定文件夹压缩为ZIP文件。

        :param source_folder: 要压缩的文件夹路径
        :param output_zip: 输出的ZIP文件路径
        """
        # 获取今天的日期
        today = date.today()
        # 如果需要特定格式，可以使用 strftime 方法
        formatted_date = today.strftime("%Y-%m-%d")
        try:
            # 使用make_archive方法进行压缩
            # 第一个参数是输出文件的基础名称（不包括扩展名）
            # 第二个参数是指定的压缩格式，这里是'zip'
            # 第三个参数是要压缩的文件夹路径
            shutil.make_archive(f"{kwargs[r'输出文件夹路径']}/{formatted_date}", 'zip', kwargs[r"文件夹路径"])
            print(f"文件夹已成功压缩为 {formatted_date}.zip")
        except Exception as e:
            print(f"压缩过程中发生错误: {e}")

    def fore_rname_mv(self, **kwargs):  # 方法名称 必须与关键字名称一致
        # 确保目标目录存在
        if not os.path.exists(kwargs[r"源目录路径"]):
            os.makedirs(kwargs[r"源目录路径"])
            # 查找源目录下所有以 .zip 结尾的文件
        zip_files = glob.glob(os.path.join(kwargs[r"源目录路径"], "*.zip"))
        if zip_files:
            # 获取第一个找到的 .zip 文件
            src_path = zip_files[0]
            print(src_path)
            # 构建源文件的完整路径
            src_path = os.path.join(kwargs[r"源目录路径"], src_path)

            # 检查文件是否存在
            if os.path.exists(src_path):
                # 确保目标目录存在
                if not os.path.exists(kwargs[r"目标目录路径"]):
                    os.makedirs(kwargs[r"目标目录路径"])
                    # 构建新文件的完整路径
                dst_path = os.path.join(kwargs[r"目标目录路径"], kwargs[r"新的文件名"])

                # 重命名并移动文件
                shutil.move(src_path, dst_path)
                print(fr"文件已从 {src_path} 移动到 {dst_path}")
        else:
            print(f"文件 {kwargs[r'新的文件名']} 不存在于 {kwargs[r'源目录路径']}")

    def send_email(self, **kwargs):  # 方法名称 必须与关键字名称一致

        """
        通过 SMTP 发送电子邮件。

        :param smtp_server: SMTP 服务器地址
        :param port: SMTP 服务器端口
        :param sender_email: 发件人邮箱地址
        :param sender_password: 发件人邮箱密码
        :param receiver_email: 收件人邮箱地址
        :param subject: 邮件主题
        :param body: 邮件正文
        :param attachment_path: 附件路径（可选）
        """
        # 获取今天的日期
        today = date.today()
        # 如果需要特定格式，可以使用 strftime 方法
        formatted_date = today.strftime("%Y-%m-%d")
        # 创建 MIMEMultipart 对象
        msg = MIMEMultipart()
        msg['From'] = kwargs["sender_email"]
        msg['To'] = kwargs["receiver_email"]
        msg['Subject'] = kwargs["subject"]

        # 添加邮件正文
        msg.attach(MIMEText(kwargs["body"], 'plain'))

        # 如果有附件，添加附件
        if kwargs[r"attachment_path"]:
            with open(f'{kwargs[r"attachment_path"]}/{formatted_date}.zip', "rb") as attachment:
                part = MIMEBase('application', 'octet-stream')
                part.set_payload(attachment.read())
                encoders.encode_base64(part)
                part.add_header('Content-Disposition',
                                f'attachment; filename="测试邮件"')
                msg.attach(part)

        # 连接到 SMTP 服务器并发送邮件
        try:
            server = smtplib.SMTP(kwargs["smtp_server"], kwargs["port"])
            server.starttls()  # 启用 TLS 加密
            server.login(kwargs["sender_email"], kwargs["sender_password"])
            server.sendmail(kwargs["sender_email"], kwargs["receiver_email"], msg.as_string())
            server.quit()
            print("邮件发送成功")
        except Exception as e:
            print(f"邮件发送失败: {e}")

    def clear_input(self, **kwargs):  # 方法名称 必须与关键字名称一致
        try:
            # 找到输入框元素
            input_box = self.driver.find_element(kwargs["定位方式"], kwargs["目标对象"])  # 替换为实际的定位器

            # 使用 JavaScript 清除输入框中的所有数据
            # self.driver.execute_script("arguments[0].value = '';", input_box)
            input_box.clear()
            print("输入框已清空")
        except Exception as e:
            print(f"发生错误: {e}")

    def double_click(self, **kwargs):  # 方法名称 必须与关键字名称一致
        element = self.driver.find_element(kwargs["定位方式"], kwargs["目标对象"]).click()
        actions = ActionChains(self.driver)
        actions.double_click(element).perform()

    def killreadonly(self, **kwargs):  # 方法名称 必须与关键字名称一致

        # 找到 input 元素
        input_element = self.driver.find_element(kwargs["定位方式"], kwargs["目标对象"])  # 根据实际情况选择合适的定位方式
        # 移除 readonly 属性
        self.driver.execute_script("arguments[0].removeAttribute('readonly');", input_element)

    def select_option_by_text(self, **kwargs):
        """
        根据文本内容选中下拉列表中的选项。

        :param kwargs: 包含定位方式、目标对象、选项定位方式、选项目标对象和传入数据的字典
        """
        # 定位下拉列表元素
        dropdown_element = self.driver.find_element(kwargs["下拉列表的定位方式"], kwargs["下拉列表的元素对象"])

        # 打开下拉列表（如果需要）
        dropdown_element.click()
        time.sleep(1)  # 等待下拉列表展开

        # 定位所有选项元素
        options_elements = self.driver.find_elements(kwargs["选项定位方式"], kwargs["选项目标对象"])

        # 遍历所有选项，检查每个选项的文本内容
        for option in options_elements:
            span_element = option.find_element(By.TAG_NAME, "span")
            if span_element.text == kwargs["传入数据"]:
                option.click()
                print(f"选中了文本为 {kwargs['传入数据']} 的选项")
                return

        print(f"未找到文本为 {kwargs['传入数据']} 的选项")
