from selenium import webdriver
from selenium.webdriver.common.by import By
import time
from selenium.webdriver.chrome.service import Service
# 指定 Chrome 浏览器的可执行文件路径
chrome_path = r'Applications/Google\Chrome\for\Testing.app/Contents/MacOS/Google\Chrome'
# 创建 ChromeOptions 对象
chrome_options = webdriver.ChromeOptions()
# 设置 Chrome 浏览器的可执行文件路径
chrome_options.binary_location = chrome_path

# 指定 ChromeDriver 的路径
chromedriver_path = '/usr/local/bin/chromedriver'
# 创建 Service 对象
service = Service(chromedriver_path)

# 初始化 WebDriver
driver = webdriver.Chrome(service=service, options=chrome_options)

# 打开网页
driver.get("http://172.22.7.60:10008/login?redirect=%2Findex")
driver.maximize_window()
driver.find_element(By.XPATH, "//*[@id='app']/div[1]/form/div[3]/div/button").click()
time.sleep(3)
driver.find_element(By.XPATH, "//*[@id='app']/div[1]/div[1]/div/div[2]/div[5]").click()
time.sleep(3)
driver.find_element(By.XPATH, "//*[@id='app']/div[1]/div[1]/div[2]/div/div[1]").click()

# 定位到下拉触发元素（例如，Bootstrap的触发按钮）
trigger_element = driver.find_element(By.XPATH,
                                      "//*[@id='app']/div[1]/div[2]/section/div/div[1]/div/form/div/div[8]/div/div/div/div/input")

# 使用JavaScript点击触发元素，打开下拉菜单
driver.execute_script("arguments[0].click();", trigger_element)

# 此时，下拉菜单应该是打开的，你可以继续进行其他操作，例如选择下拉菜单中的选项
# 例如，选择下拉菜单中的一个选项
option = driver.find_element(By.XPATH, "/html/body/div[5]/div[1]/div[1]/ul/li[2]/span")
option.click()

# 测试完成后关闭浏览器
driver.quit()
